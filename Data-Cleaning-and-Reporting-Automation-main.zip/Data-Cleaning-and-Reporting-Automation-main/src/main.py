from pathlib import Path
import sys
from typing import Optional

from cleaner import DataCleaner
from reporter import Reporter
from visualizer import Visualizer


def find_input_file(data_folder: Path) -> Optional[Path]:
    """Find the first Excel or CSV file in the data folder."""
    patterns = ["*.xlsx", "*.xls", "*.csv"]
    for pattern in patterns:
        files = sorted(data_folder.glob(pattern))
        if files:
            return files[0]
    return None


def generate_sample_dataset(output_path: Path) -> Path:
    """Generate a sample Excel dataset if no input file exists."""
    import pandas as pd

    sample_data = {
        "Customer Name": [" Alice ", "Bob", "Charlie", "Dana", "Evan", "Bob", None, "Frank"],
        "Department": ["Sales", "Marketing", "Sales", "Sales", "HR", "Marketing", "HR", "Engineering"],
        "Sales Amount": [100.0, 150.5, None, 200.0, 50.0, 150.5, 70.0, 180.5],
        "Transaction Date": ["2026-01-10", "2026-01-11", "2026-01-12", None, "2026-01-14", "2026-01-11", "2026-01-15", "2026-01-16"],
    }
    df = pd.DataFrame(sample_data)
    output_path.parent.mkdir(parents=True, exist_ok=True)
    df.to_excel(output_path, index=False, engine="openpyxl")
    return output_path


def main() -> int:
    """Main entry point for automation."""
    root_folder = Path(__file__).resolve().parent.parent
    data_folder = root_folder / "data"
    reports_folder = root_folder / "reports"
    data_folder.mkdir(parents=True, exist_ok=True)
    reports_folder.mkdir(parents=True, exist_ok=True)

    input_file = find_input_file(data_folder)
    if input_file is None:
        print("No Excel or CSV file found in the data folder.")
        input_file = generate_sample_dataset(data_folder / "sample_data.xlsx")
        print(f"Sample dataset created at: {input_file}")
    else:
        print(f"Found input dataset: {input_file.name}")

    try:
        cleaner = DataCleaner(input_file)
        cleaned_df = cleaner.clean_data()
        cleaned_file = cleaner.save_cleaned_data(reports_folder / "cleaned_data.xlsx")

        summary_stats = cleaned_df.select_dtypes(include=["number"]).describe().round(2)
        reporter = Reporter(
            dataset_name=input_file.name,
            rows_before=cleaner.rows_before,
            rows_after=cleaner.rows_after,
            duplicates_removed=cleaner.duplicates_removed,
            missing_values_fixed=cleaner.missing_values_fixed,
            summary_stats=summary_stats,
        )
        report_file = reporter.save_report(reports_folder / "report.txt")

        visualizer = Visualizer(cleaned_df, reports_folder)
        bar_path = visualizer.create_bar_chart()
        pie_path = visualizer.create_pie_chart()

        print("Automation completed successfully.")
        print(f"Cleaned dataset saved to: {cleaned_file}")
        print(f"Text report saved to: {report_file}")
        if bar_path:
            print(f"Bar chart saved to: {bar_path}")
        else:
            print("Bar chart could not be generated due to missing numeric data.")
        if pie_path:
            print(f"Pie chart saved to: {pie_path}")
        else:
            print("Pie chart could not be generated due to missing categorical or numeric data.")
        return 0
    except FileNotFoundError as error:
        print(f"File error: {error}")
        return 1
    except ValueError as error:
        print(f"Value error: {error}")
        return 1
    except Exception as error:
        print(f"Unexpected error: {error}")
        return 1


if __name__ == "__main__":
    sys.exit(main())
