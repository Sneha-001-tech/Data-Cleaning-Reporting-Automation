from datetime import datetime
from pathlib import Path
import pandas as pd


class Reporter:
    """Generate a text report from cleaned dataset metadata and statistics."""

    def __init__(
        self,
        dataset_name: str,
        rows_before: int,
        rows_after: int,
        duplicates_removed: int,
        missing_values_fixed: int,
        summary_stats: pd.DataFrame,
    ):
        self.dataset_name = dataset_name
        self.rows_before = rows_before
        self.rows_after = rows_after
        self.duplicates_removed = duplicates_removed
        self.missing_values_fixed = missing_values_fixed
        self.summary_stats = summary_stats
        self.processing_date = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

    def generate_report_text(self) -> str:
        """Return a nicely formatted text summary report."""
        report_lines = [
            "DATA CLEANING & REPORTING AUTOMATION REPORT",
            "=================================================",
            f"Dataset name: {self.dataset_name}",
            f"Processing date: {self.processing_date}",
            f"Rows before cleaning: {self.rows_before}",
            f"Rows after cleaning: {self.rows_after}",
            f"Duplicates removed: {self.duplicates_removed}",
            f"Missing values handled: {self.missing_values_fixed}",
            "",
            "SUMMARY STATISTICS:",
        ]

        if self.summary_stats.empty:
            report_lines.append("No numeric columns were available for summary statistics.")
        else:
            report_lines.append(self.summary_stats.to_string())

        report_lines.append("=================================================")
        return "\n".join(report_lines)

    def save_report(self, output_path: Path) -> Path:
        """Save the text report to the specified path."""
        output_path = Path(output_path)
        output_path.parent.mkdir(parents=True, exist_ok=True)
        report_text = self.generate_report_text()
        output_path.write_text(report_text, encoding="utf-8")
        return output_path
