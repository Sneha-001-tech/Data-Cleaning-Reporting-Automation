from pathlib import Path
import pandas as pd


class DataCleaner:
    """Load, clean, and save data from Excel or CSV files."""

    def __init__(self, input_path: Path):
        self.input_path = Path(input_path)
        self.cleaned_df = pd.DataFrame()
        self.rows_before = 0
        self.rows_after = 0
        self.duplicates_removed = 0
        self.missing_values_fixed = 0
        self.dataset_name = self.input_path.name

    def load_data(self) -> pd.DataFrame:
        """Load data from Excel or CSV and return a DataFrame."""
        if not self.input_path.exists():
            raise FileNotFoundError(f"Input file not found: {self.input_path}")

        suffix = self.input_path.suffix.lower()
        if suffix == ".csv":
            return pd.read_csv(self.input_path)
        if suffix in [".xls", ".xlsx"]:
            return pd.read_excel(self.input_path, engine="openpyxl")

        raise ValueError("Unsupported file type. Please use .csv or .xlsx.")

    def standardize_columns(self, df: pd.DataFrame) -> pd.DataFrame:
        """Standardize column names for consistency."""
        df = df.copy()
        df.columns = [
            str(column).strip().lower().replace(" ", "_").replace("-", "_")
            for column in df.columns
        ]
        return df

    def trim_text_fields(self, df: pd.DataFrame) -> pd.DataFrame:
        """Trim extra spaces from text fields and mark empty strings as missing."""
        df = df.copy()
        text_columns = df.select_dtypes(include=["object", "string"]).columns
        for column in text_columns:
            # Only strip text fields and preserve missing values.
            df[column] = df[column].where(df[column].isna(), df[column].astype(str).str.strip())
            df[column] = df[column].replace({"": pd.NA, "nan": pd.NA, "None": pd.NA, "none": pd.NA})
        return df

    def handle_missing_values(self, df: pd.DataFrame) -> pd.DataFrame:
        """Fill missing values for numeric and text columns."""
        df = df.copy()
        missing_before = df.isna().sum().sum()

        for column in df.columns:
            if df[column].dtype.kind in "biufc":
                if df[column].isna().any():
                    mean_value = df[column].mean()
                    df[column] = df[column].fillna(mean_value)
            else:
                if df[column].isna().any():
                    df[column] = df[column].fillna("Unknown")

        missing_after = df.isna().sum().sum()
        self.missing_values_fixed = int(missing_before - missing_after)
        return df

    def clean_data(self) -> pd.DataFrame:
        """Run the full cleaning workflow and return the cleaned DataFrame."""
        df = self.load_data()
        self.rows_before = len(df)

        # Remove rows that are empty across all columns.
        df = df.dropna(how="all")

        # Standardize and trim text fields.
        df = self.standardize_columns(df)
        df = self.trim_text_fields(df)

        # Remove duplicates after cleaning text and columns.
        rows_after_empty_removed = len(df)
        df = df.drop_duplicates()
        self.duplicates_removed = int(rows_after_empty_removed - len(df))

        # Fix missing values last so that reporting counts are accurate.
        df = self.handle_missing_values(df)
        self.rows_after = len(df)

        self.cleaned_df = df
        return df

    def save_cleaned_data(self, output_path: Path) -> Path:
        """Save the cleaned DataFrame to an Excel file."""
        output_path = Path(output_path)
        output_path.parent.mkdir(parents=True, exist_ok=True)
        self.cleaned_df.to_excel(output_path, index=False, engine="openpyxl")
        return output_path
