from pathlib import Path
import matplotlib.pyplot as plt
import pandas as pd
from typing import Optional


class Visualizer:
    """Generate charts for cleaned datasets and save them as PNG images."""

    def __init__(self, df: pd.DataFrame, output_dir: Path):
        self.df = df.copy()
        self.output_dir = Path(output_dir)
        self.output_dir.mkdir(parents=True, exist_ok=True)

    def create_bar_chart(self) -> Optional[Path]:
        """Create a bar chart from numeric columns."""
        numeric_df = self.df.select_dtypes(include=["number"])
        if numeric_df.empty:
            return None

        values = numeric_df.mean().sort_values(ascending=False)
        chart_path = self.output_dir / "bar_chart.png"

        fig, ax = plt.subplots(figsize=(10, 6))
        values.plot(kind="bar", color="steelblue", ax=ax)
        ax.set_title("Average Values by Numeric Column")
        ax.set_ylabel("Average Value")
        ax.set_xlabel("Numeric Columns")
        ax.grid(axis="y", alpha=0.3)

        fig.tight_layout()
        fig.savefig(chart_path, dpi=150)
        plt.close(fig)
        return chart_path

    def create_pie_chart(self) -> Path | None:
        """Create a pie chart for categorical data or a numeric distribution."""
        categorical_df = self.df.select_dtypes(include=["object", "category", "string"])
        chart_path = self.output_dir / "pie_chart.png"

        if not categorical_df.empty:
            value_counts = categorical_df.iloc[:, 0].fillna("Unknown").value_counts()
            if len(value_counts) < 2:
                return None
            value_counts = value_counts.head(8)
            fig, ax = plt.subplots(figsize=(8, 8))
            value_counts.plot(kind="pie", autopct="%.1f%%", startangle=90, ax=ax)
            ax.set_ylabel("")
            ax.set_title(f"Distribution of {categorical_df.columns[0]}")
            ax.axis("equal")
            fig.tight_layout()
            fig.savefig(chart_path, dpi=150)
            plt.close(fig)
            return chart_path

        numeric_df = self.df.select_dtypes(include=["number"])
        if numeric_df.empty:
            return None

        first_numeric = numeric_df.iloc[:, 0]
        value_counts = pd.cut(first_numeric, bins=5).value_counts().sort_index()
        fig, ax = plt.subplots(figsize=(8, 8))
        value_counts.plot(kind="pie", autopct="%.1f%%", startangle=90, ax=ax)
        ax.set_ylabel("")
        ax.set_title(f"Value Distribution of {first_numeric.name}")
        ax.axis("equal")
        fig.tight_layout()
        fig.savefig(chart_path, dpi=150)
        plt.close(fig)
        return chart_path
