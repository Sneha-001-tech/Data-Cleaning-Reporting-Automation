Data Cleaning & Reporting Automation is a Python project that automates the preprocessing, reporting, and visualization of Excel and CSV sales datasets using pandas, openpyxl, and matplotlib.
