# Project Documentation

## Purpose

Data Cleaning & Reporting Automation is designed to streamline the data preparation process for sales datasets. The project demonstrates an end-to-end workflow that includes data ingestion, cleaning, reporting, and visualization without relying on a database.

## Architecture

The project follows a modular design with separate responsibilities:

- `src/cleaner.py` handles data ingestion and transformation.
- `src/reporter.py` generates a professional text report summarizing the cleaning process and numeric statistics.
- `src/visualizer.py` produces visualization outputs in PNG format.
- `src/main.py` orchestrates the workflow and coordinates the input and output file locations.

## Module Responsibilities

### `cleaner.py`
- Loads data from Excel or CSV files.
- Removes duplicate rows.
- Drops rows that are completely empty.
- Standardizes column names to lowercase with underscore separators.
- Trims whitespace from text fields.
- Handles missing values by filling numeric fields with the column mean and text fields with `Unknown`.
- Saves the cleaned dataset to `reports/cleaned_data.xlsx`.

### `reporter.py`
- Collects metadata from the cleaning process.
- Formats a text report with dataset details, processing statistics, and summary tables.
- Writes the report to `reports/report.txt`.

### `visualizer.py`
- Creates a bar chart from numeric column averages.
- Creates a pie chart from the first available categorical column or a numeric distribution.
- Saves charts to `reports/bar_chart.png` and `reports/pie_chart.png`.

### `main.py`
- Detects input files in the `data/` folder.
- Generates a sample dataset automatically if no input file is present.
- Runs the full pipeline and reports completion status.

## Data Flow

1. Input file is detected from `data/`.
2. Data is loaded into a pandas DataFrame.
3. Cleaning operations are applied.
4. Cleaned data is written to `reports/cleaned_data.xlsx`.
5. Summary statistics are generated and written to `reports/report.txt`.
6. Visualizations are exported to PNG images.

## File Structure

- `data/`: input datasets for the project.
- `reports/`: output files produced by the automation process.
- `src/`: source code modules for cleaning, reporting, visualization, and orchestration.
- `requirements.txt`: Python dependencies.
- `README.md`: project overview and usage instructions.
- `LICENSE`: MIT license file.

## Extension Opportunities

Future versions of this project can include:

- A command-line interface for custom input selection.
- Support for batch processing multiple files.
- Configurable cleaning rules via external settings.
- Additional visualizations such as line charts and scatter plots.
- Built-in unit tests for validation and regression testing.
