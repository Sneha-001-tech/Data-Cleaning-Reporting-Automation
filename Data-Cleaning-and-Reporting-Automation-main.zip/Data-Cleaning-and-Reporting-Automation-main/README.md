# Data Cleaning & Reporting Automation

## Project Overview

Data Cleaning & Reporting Automation is a Python project that automates data preprocessing, summary reporting, and visualization for sales datasets. It is designed for internship-level portfolios and supports Excel and CSV input formats without using any database.

## Features

- Automatic detection of `.xlsx` and `.csv` files in the `data/` folder
- Removal of duplicate records and empty rows
- Missing value handling for numeric and text fields
- Standardized column names and trimmed text values
- Export of cleaned data to `reports/cleaned_data.xlsx`
- Automatic calculation of rows before and after cleaning
- Duplicate removal and missing value fix counts
- Summary statistics for numeric columns
- Bar chart and pie chart generation in PNG format
- Professional automation report saved to `reports/report.txt`

## Technologies Used

- Python 3.8+
- pandas
- openpyxl
- matplotlib
- pathlib

## Folder Structure

```
Data Cleaning & Reporting Automation/
│
├── data/
│   └── sales_data.csv
│
├── reports/
│   └── .gitkeep
│
├── src/
│   ├── cleaner.py
│   ├── reporter.py
│   ├── visualizer.py
│   └── main.py
│
├── .gitignore
├── LICENSE
├── PROJECT_DOCUMENTATION.md
├── README.md
├── requirements.txt
└── .github/
    ├── REPOSITORY_DESCRIPTION.md
    └── TOPICS.md
```

## Installation

1. Clone the repository:

```bash
git clone https://github.com/your-username/data-cleaning-reporting-automation.git
cd "Data Cleaning & Reporting Automation"
```

2. Create a virtual environment (recommended):

```bash
python -m venv .venv
```

3. Activate the virtual environment:

- PowerShell:

```powershell
.\.venv\Scripts\Activate.ps1
```

- Command Prompt:

```cmd
.\.venv\Scripts\activate.bat
```

4. Install required packages:

```bash
pip install -r requirements.txt
```

## How To Run

1. Confirm that `data/sales_data.csv` is present in the `data/` folder.
2. Execute the main script:

```bash
python src/main.py
```

3. Review the generated output files in the `reports/` folder.

## Sample Output

The automation produces the following output files:

- `reports/cleaned_data.xlsx`
- `reports/report.txt`
- `reports/bar_chart.png`
- `reports/pie_chart.png`

The `report.txt` file includes:

- Dataset name
- Processing date
- Rows before cleaning
- Rows after cleaning
- Duplicates removed
- Missing values handled
- Numeric summary statistics including averages, totals, minimum, and maximum values

## Screenshots

After running the script, view the generated chart files:

- `reports/bar_chart.png`
- `reports/pie_chart.png`

These files visually summarize numeric trends and category distributions from the cleaned dataset.

## Learning Outcomes

- Built a clean and modular data pipeline in Python
- Applied pandas for extract-transform-load (ETL) workflows
- Used openpyxl to write Excel outputs
- Created analytics visualizations with matplotlib
- Practiced professional repository organization and documentation
- Prepared a submission-ready project for internship evaluation

## Future Improvements

- Add command-line options for custom input selection
- Support batch processing of multiple dataset files
- Add configuration files for cleaning rules and reporting options
- Expand visualization options with line charts and heatmaps
- Add unit tests for validation and regression checks
